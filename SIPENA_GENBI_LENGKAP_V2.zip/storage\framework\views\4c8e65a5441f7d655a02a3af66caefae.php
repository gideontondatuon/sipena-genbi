<?php $__env->startSection('title', 'Notifikasi'); ?>
<?php $__env->startSection('subtitle', 'Pemberitahuan status target dan laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-9">
        <div class="content-card">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <div>
                    <h5 class="fw-bold mb-1"><i class="bi bi-bell-fill me-2 text-primary"></i>Notifikasi Saya</h5>
                    <small class="text-muted">Informasi terbaru terkait target dan status laporan Anda</small>
                </div>

                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <?php
                        $unreadCount = $notifikasis->where('is_read', false)->count();
                    ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($unreadCount > 0): ?>
                        <form action="<?php echo e(route('notifikasi.read-all')); ?>" method="POST" class="m-0">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-primary rounded-4 btn-sm fw-semibold"><i class="bi bi-check-all me-1"></i> Tandai Semua Dibaca</button>
                        </form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($notifikasis->count() > 0): ?>
                        <form action="<?php echo e(route('notifikasi.clear-all')); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus seluruh notifikasi?')" class="m-0">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-danger rounded-4 btn-sm fw-semibold"><i class="bi bi-trash3-fill me-1"></i> Hapus Semua Notifikasi</button>
                        </form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $notifikasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="border rounded-4 p-3 mb-3 transition-all <?php echo e($notif->is_read ? 'bg-white' : 'bg-light border-primary shadow-sm'); ?>">
                    <div class="d-flex gap-3 align-items-start">
                        <div class="fs-2 pt-1">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($notif->tipe === 'target'): ?>
                                <i class="bi bi-bullseye text-primary"></i>
                            <?php elseif($notif->tipe === 'warning'): ?>
                                <i class="bi bi-exclamation-triangle-fill text-warning"></i>
                            <?php elseif($notif->tipe === 'ditolak'): ?>
                                <i class="bi bi-x-circle-fill text-danger"></i>
                            <?php else: ?>
                                <i class="bi bi-check-circle-fill text-success"></i>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="flex-grow-1">
                            <div class="d-flex justify-content-between align-items-start gap-2">
                                <a href="<?php echo e(route('notifikasi.open', $notif->id)); ?>" class="text-decoration-none text-dark fw-bold fs-6 flex-grow-1">
                                    <?php echo e($notif->judul); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$notif->is_read): ?>
                                        <span class="badge bg-danger ms-2 rounded-pill fs-7">Baru</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </a>

                                <form action="<?php echo e(route('notifikasi.destroy', $notif->id)); ?>" method="POST" onsubmit="return confirm('Hapus notifikasi ini?')" class="m-0">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-link text-danger p-0 border-0 fs-6" title="Hapus Notifikasi"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>

                            <a href="<?php echo e(route('notifikasi.open', $notif->id)); ?>" class="text-decoration-none text-muted d-block small mt-1">
                                <?php echo e($notif->pesan); ?>

                            </a>

                            <div class="d-flex justify-content-between align-items-center mt-2 pt-2 border-top border-light">
                                <small class="text-muted" style="font-size: 0.75rem;">
                                    <i class="bi bi-clock me-1"></i> <?php echo e($notif->created_at->diffForHumans()); ?>

                                </small>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$notif->is_read): ?>
                                    <a href="<?php echo e(route('notifikasi.open', $notif->id)); ?>" class="btn btn-sm btn-light text-primary fw-semibold rounded-pill py-0.5 px-2.5 fs-7">
                                        <i class="bi bi-envelope-open me-1"></i> Tandai Dibaca
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted fs-7"><i class="bi bi-check2-all text-success me-1"></i> Sudah Dibaca</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div class="text-center py-5 text-muted">
                    <i class="bi bi-bell-slash fs-1 d-block mb-2 text-secondary"></i>
                    Belum ada notifikasi saat ini.
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project Laravel\sipena-genbi\resources\views/notifikasi.blade.php ENDPATH**/ ?>