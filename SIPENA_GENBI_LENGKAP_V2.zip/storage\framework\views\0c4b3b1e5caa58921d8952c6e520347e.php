<?php $__env->startSection('title', 'Akun Instagram'); ?>
<?php $__env->startSection('subtitle', 'Kelola daftar akun Instagram yang menjadi target laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-lg-5">
        <div class="content-card">
            <h5 class="fw-bold mb-1">Tambah Akun Instagram</h5>
            <p class="text-muted mb-4">Masukkan akun Instagram yang wajib dipantau oleh anggota.</p>

            <form action="<?php echo e(route('admin.akun-instagram.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nama Akun</label>
                    <input type="text" name="nama_akun" class="form-control" placeholder="Contoh: BI Sulut" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Username Instagram</label>
                    <input type="text" name="username" class="form-control" placeholder="Contoh: @bi_sulut" required>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold">Keterangan</label>
                    <textarea name="keterangan" class="form-control" rows="3" placeholder="Keterangan akun"></textarea>
                </div>

                <button type="submit" class="btn btn-bi w-100">Simpan Akun</button>
            </form>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="content-card">
            <h5 class="fw-bold mb-3">Daftar Akun Instagram</h5>

            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>Nama Akun</th>
                            <th>Username</th>
                            <th>Status</th>
                            <th>Total Target</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $akunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td class="fw-semibold"><?php echo e($akun->nama_akun); ?></td>
                                <td><?php echo e($akun->username); ?></td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($akun->status === 'aktif'): ?>
                                        <span class="badge bg-success-subtle text-success rounded-pill px-3 py-2">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary-subtle text-secondary rounded-pill px-3 py-2">Nonaktif</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td><?php echo e($akun->target_harians_count); ?></td>
                                <td>
                                    <div class="d-flex gap-1">
                                        <button class="btn btn-sm btn-outline-primary rounded-4" data-bs-toggle="modal" data-bs-target="#modalEditAkun<?php echo e($akun->id); ?>"><i class="bi bi-pencil-square me-1"></i> Edit</button>
                                        <form action="<?php echo e(route('admin.akun-instagram.destroy', $akun->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus akun Instagram <?php echo e($akun->nama_akun); ?> (<?php echo e($akun->username); ?>)?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger rounded-4"><i class="bi bi-trash-fill me-1"></i> Hapus</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>

                            <!-- Modal Edit Akun IG -->
                            <div class="modal fade" id="modalEditAkun<?php echo e($akun->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content rounded-4 border-0">
                                        <form action="<?php echo e(route('admin.akun-instagram.update', $akun->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-header border-0 pb-0">
                                                <h5 class="modal-title fw-bold">Edit Akun <?php echo e($akun->nama_akun); ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Nama Akun</label>
                                                    <input type="text" name="nama_akun" class="form-control" value="<?php echo e($akun->nama_akun); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Username Instagram</label>
                                                    <input type="text" name="username" class="form-control" value="<?php echo e($akun->username); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Status</label>
                                                    <select name="status" class="form-select">
                                                        <option value="aktif" <?php echo e($akun->status === 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                                                        <option value="nonaktif" <?php echo e($akun->status === 'nonaktif' ? 'selected' : ''); ?>>Nonaktif</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Keterangan</label>
                                                    <textarea name="keterangan" class="form-control" rows="3"><?php echo e($akun->keterangan); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer border-0">
                                                <button type="button" class="btn btn-secondary rounded-4" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-bi">Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">Belum ada akun Instagram target.</td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project Laravel\sipena-genbi\resources\views/admin/akun-instagram.blade.php ENDPATH**/ ?>