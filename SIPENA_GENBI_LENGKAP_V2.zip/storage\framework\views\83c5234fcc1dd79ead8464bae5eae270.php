<?php $__env->startSection('title', 'Dashboard Personal SIPENA GenBI'); ?>
<?php $__env->startSection('subtitle', 'Asisten otomatis pembuatan laporan engagement Instagram pengganti Word'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-md-4">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="stat-label">Total Postingan Terlaporkan</div>
                    <div class="stat-number text-primary"><?php echo e(number_format($sudahUpload)); ?></div>
                    <small class="text-muted"><i class="bi bi-file-earmark-check me-1"></i>laporan tersimpan</small>
                </div>
                <div class="stat-icon bg-primary-subtle text-primary">
                    <i class="bi bi-journal-check"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-md-4">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="stat-label">Format Dokumen</div>
                    <div class="stat-number text-success">PDF / Print</div>
                    <small class="text-muted"><i class="bi bi-printer me-1"></i>siap cetak otomatis</small>
                </div>
                <div class="stat-icon bg-success-subtle text-success">
                    <i class="bi bi-printer-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-md-4">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="stat-label">Aksi Cepat</div>
                    <div class="mt-2">
                        <a href="<?php echo e(route('user.laporan.create')); ?>" class="btn btn-bi btn-sm w-100 mb-1">+ Upload Screenshot</a>
                    </div>
                </div>
                <div class="stat-icon bg-danger-subtle text-danger">
                    <i class="bi bi-cloud-arrow-up-fill"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="content-card">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div>
            <h5 class="fw-bold mb-1"><i class="bi bi-star-fill text-warning me-2"></i>Status Laporan Per Akun Instagram</h5>
            <small class="text-muted">Setiap kali akun Instagram target posting, upload bukti screenshot di sini</small>
        </div>
        <div class="d-flex gap-2 flex-column flex-sm-row w-100 w-sm-auto">
            <a href="<?php echo e(route('user.laporan.create')); ?>" class="btn btn-bi w-100 w-sm-auto">+ Upload Laporan Baru</a>
            <a href="<?php echo e(route('user.preview-laporan')); ?>" class="btn btn-outline-primary rounded-4 w-100 w-sm-auto"><i class="bi bi-printer me-1"></i> Preview Laporan Bulanan</a>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>Akun Instagram</th>
                    <th>Postingan Terakhir</th>
                    <th>Jumlah Ter-upload</th>
                    <th>Aksi Cepat</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr>
                        <td class="fw-semibold">
                            <i class="bi bi-instagram text-primary me-2"></i><?php echo e($t->akun); ?>

                        </td>
                        <td><?php echo e($t->tanggal); ?></td>
                        <td>
                            <span class="badge bg-primary-subtle text-primary fw-bold px-3 py-2">
                                <?php echo e($t->upload); ?> Postingan
                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('user.laporan.create')); ?>" class="btn btn-sm btn-outline-primary rounded-3">+ Upload Screenshot</a>
                        </td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <tr>
                        <td colspan="4" class="text-center py-4 text-muted">Belum ada akun Instagram yang terdaftar.</td>
                    </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project Laravel\sipena-genbi\resources\views/user/dashboard.blade.php ENDPATH**/ ?>