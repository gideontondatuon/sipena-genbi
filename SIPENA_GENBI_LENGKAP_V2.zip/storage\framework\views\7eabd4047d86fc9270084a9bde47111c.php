

<?php $__env->startSection('title', 'Halaman Tidak Ditemukan'); ?>
<?php $__env->startSection('subtitle', 'Maaf, halaman yang Anda cari tidak tersedia'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="content-card text-center py-5">
            <div style="font-size: 72px;">🔎</div>
            <h1 class="fw-bold mt-3" style="color: var(--bi-blue);">404</h1>
            <h5 class="fw-bold">Halaman Tidak Ditemukan</h5>
            <p class="text-muted">
                Halaman yang Anda buka mungkin sudah dipindahkan atau belum tersedia.
            </p>

            <a href="/user/dashboard" class="btn btn-bi mt-3">
                Kembali ke Dashboard
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project Laravel\sipena-genbi\resources\views/errors/404.blade.php ENDPATH**/ ?>