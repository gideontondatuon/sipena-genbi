<?php $__env->startSection('title', 'Rekap Anggota'); ?>
<?php $__env->startSection('subtitle', 'Rekap kelengkapan laporan anggota GenBI Komisariat Polimdo'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-card">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div>
            <h5 class="fw-bold mb-1">Rekap Kelengkapan Anggota</h5>
            <small class="text-muted">Daftar anggota lengkap, belum lengkap, dan belum upload</small>
        </div>

        <div class="d-flex gap-2">
            <a href="<?php echo e(route('admin.export.xlsx', ['tanggal_mulai' => $tanggalMulai, 'tanggal_selesai' => $tanggalSelesai, 'status' => request('status')])); ?>" class="btn btn-outline-success rounded-4"><i class="bi bi-file-earmark-excel me-1"></i> Export Excel (.xlsx)</a>
            <a href="<?php echo e(route('admin.preview-rekap', ['tanggal_mulai' => $tanggalMulai, 'tanggal_selesai' => $tanggalSelesai, 'status' => request('status')])); ?>" class="btn btn-bi rounded-4"><i class="bi bi-file-earmark-pdf me-1"></i> Preview / Cetak PDF Rekap</a>
        </div>
    </div>

    <form method="GET" action="<?php echo e(route('admin.rekap.index')); ?>" class="row g-3 mb-4 align-items-end">
        <div class="col-md-3">
            <label class="form-label fw-semibold small text-muted"><i class="bi bi-calendar-event me-1 text-primary"></i> Dari Tanggal</label>
            <input type="date" name="tanggal_mulai" class="form-control" value="<?php echo e($tanggalMulai); ?>" onchange="this.form.submit()">
        </div>

        <div class="col-md-3">
            <label class="form-label fw-semibold small text-muted"><i class="bi bi-calendar-check me-1 text-primary"></i> Sampai Tanggal</label>
            <input type="date" name="tanggal_selesai" class="form-control" value="<?php echo e($tanggalSelesai); ?>" onchange="this.form.submit()">
        </div>

        <div class="col-md-3">
            <label class="form-label fw-semibold small text-muted"><i class="bi bi-funnel me-1 text-primary"></i> Status Filter</label>
            <select name="status" class="form-select" onchange="this.form.submit()">
                <option value="Semua Status">Semua Status</option>
                <option value="Lengkap" <?php echo e(request('status') === 'Lengkap' ? 'selected' : ''); ?>>Lengkap</option>
                <option value="Belum Lengkap" <?php echo e(request('status') === 'Belum Lengkap' ? 'selected' : ''); ?>>Belum Lengkap</option>
                <option value="Belum Upload" <?php echo e(request('status') === 'Belum Upload' ? 'selected' : ''); ?>>Belum Upload</option>
            </select>
        </div>

        <div class="col-md-3">
            <label class="form-label fw-semibold small text-muted"><i class="bi bi-search me-1 text-primary"></i> Cari Anggota</label>
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Cari nama..." value="<?php echo e(request('search')); ?>">
                <button type="submit" class="btn btn-outline-secondary"><i class="bi bi-search"></i></button>
            </div>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>Nama Anggota</th>
                    <th>Target</th>
                    <th>Upload</th>
                    <th>Kurang</th>
                    <th>Valid</th>
                    <th>Ditolak</th>
                    <th>Status</th>
                    <th>Laporan</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr>
                        <td class="fw-semibold"><?php echo e($m->name); ?></td>
                        <td><?php echo e($m->target); ?></td>
                        <td><?php echo e($m->upload); ?></td>
                        <td class="<?php echo e($m->kurang > 0 ? 'text-danger fw-bold' : ''); ?>"><?php echo e($m->kurang > 0 ? $m->kurang : '-'); ?></td>
                        <td class="text-success fw-bold"><?php echo e($m->valid); ?></td>
                        <td class="<?php echo e($m->ditolak > 0 ? 'text-danger' : ''); ?>"><?php echo e($m->ditolak); ?></td>
                        <td><span class="badge <?php echo e($m->badgeClass); ?> rounded-pill px-3 py-2"><?php echo e($m->status); ?></span></td>
                        <td>
                            <a href="<?php echo e(route('admin.preview-laporan', ['user_id' => $m->id, 'tanggal_mulai' => $tanggalMulai, 'tanggal_selesai' => $tanggalSelesai])); ?>" class="btn btn-sm btn-outline-primary rounded-4">Preview</a>
                        </td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-muted">Data rekap anggota tidak ditemukan.</td>
                    </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project Laravel\sipena-genbi\resources\views/admin/rekap.blade.php ENDPATH**/ ?>