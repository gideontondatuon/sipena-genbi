<?php $__env->startSection('title', 'Target Harian'); ?>
<?php $__env->startSection('subtitle', 'Atur jumlah postingan wajib berdasarkan akun dan tanggal'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-lg-5">
        <div class="content-card">
            <h5 class="fw-bold mb-1">Input Target Postingan</h5>
            <p class="text-muted mb-4">Admin dapat mengatur target harian untuk wajib dipenuhi anggota.</p>

            <form action="<?php echo e(route('admin.target-harian.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Akun Instagram</label>
                    <select name="akun_instagram_id" class="form-select" required>
                        <option value="">Pilih akun Instagram</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $akunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($akun->id); ?>"><?php echo e($akun->nama_akun); ?> (<?php echo e($akun->username); ?>)</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Tanggal Postingan</label>
                    <input type="date" name="tanggal" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Jumlah Target Postingan</label>
                    <input type="number" name="jumlah_target" class="form-control" placeholder="Contoh: 5" min="1" value="1" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Deadline Upload</label>
                    <input type="datetime-local" name="deadline" class="form-control" value="<?php echo e(date('Y-m-d\TH:i', strtotime('+2 days'))); ?>" required>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold">Keterangan / Instruksi (Opsional)</label>
                    <textarea name="keterangan" class="form-control" rows="2" placeholder="Catatan instruksi untuk anggota"></textarea>
                </div>

                <button type="submit" class="btn btn-bi w-100">Simpan Target</button>
            </form>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="content-card">
            <h5 class="fw-bold mb-3">Target Aktif</h5>

            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>Akun</th>
                            <th>Tanggal</th>
                            <th>Target</th>
                            <th>Deadline</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $targetList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td class="fw-semibold"><?php echo e($target->akunInstagram->nama_akun ?? '-'); ?></td>
                                <td><?php echo e($target->tanggal->format('d M Y')); ?></td>
                                <td><span class="badge bg-primary rounded-pill px-2 py-1"><?php echo e($target->jumlah_target); ?></span></td>
                                <td><?php echo e($target->deadline ? $target->deadline->format('d M Y H:i') : '-'); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary rounded-4 me-1" data-bs-toggle="modal" data-bs-target="#modalEditTarget<?php echo e($target->id); ?>">Edit</button>
                                    <form action="<?php echo e(route('admin.target-harian.destroy', $target->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus target harian ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger rounded-4">
                                            <i class="bi bi-trash"></i> Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Modal Edit Target -->
                            <div class="modal fade" id="modalEditTarget<?php echo e($target->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content rounded-4 border-0">
                                        <form action="<?php echo e(route('admin.target-harian.update', $target->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-header border-0 pb-0">
                                                <h5 class="modal-title fw-bold">Edit Target <?php echo e($target->akunInstagram->nama_akun ?? ''); ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Akun Instagram</label>
                                                    <select name="akun_instagram_id" class="form-select" required>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $akunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                            <option value="<?php echo e($akun->id); ?>" <?php echo e($target->akun_instagram_id == $akun->id ? 'selected' : ''); ?>><?php echo e($akun->nama_akun); ?></option>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Tanggal Postingan</label>
                                                    <input type="date" name="tanggal" class="form-control" value="<?php echo e($target->tanggal->format('Y-m-d')); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Jumlah Target</label>
                                                    <input type="number" name="jumlah_target" class="form-control" value="<?php echo e($target->jumlah_target); ?>" min="1" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Deadline Upload</label>
                                                    <input type="datetime-local" name="deadline" class="form-control" value="<?php echo e($target->deadline ? $target->deadline->format('Y-m-d\TH:i') : ''); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Keterangan</label>
                                                    <textarea name="keterangan" class="form-control" rows="2"><?php echo e($target->keterangan); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer border-0">
                                                <button type="button" class="btn btn-secondary rounded-4" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-bi">Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">Belum ada target harian.</td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project Laravel\sipena-genbi\resources\views/admin/target-harian.blade.php ENDPATH**/ ?>